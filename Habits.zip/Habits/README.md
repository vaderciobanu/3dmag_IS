# Habits – Habitica-like Backend API

Proiect pentru materia Ingineria Sistemelor (IS): o aplicație tip Habitica care permite
gestiunea de utilizatori, task-uri și reward-uri, cu mecanică de gamification
(XP, level, health, gold).

Backend-ul este un API REST scris în ASP.NET Core 8, cu persistare în SQLite și
Entity Framework Core. Aplicația poate rula atât local, cât și în container Docker.

---

## Tehnologii

- .NET 8 / ASP.NET Core Web API
- Entity Framework Core + SQLite
- Swagger / OpenAPI pentru documentarea endpoint-urilor
- Docker + docker-compose

---

## Structura soluției

- `Habits.sln` – soluția .NET
- `Habits.Api/` – proiectul Web API
  - `Entities/` – entitățile de domeniu (User, HabitTask, Reward etc.)
  - `Data/HabitsDbContext.cs` – contextul EF Core
  - `Dtos/` – DTO-urile pentru request/response
  - `Services/` – logica de business (UserService, TaskService, RewardService)
  - `Controllers/` – controllerele API
  - `Migrations/` – migrații EF Core
  - `habits.db` – baza de date SQLite
  - `Dockerfile` – imaginea Docker pentru API
- `docker-compose.yml` – rularea API-ului în container

---

## Cum rulez local (fără Docker)

1. Asigură-te că ai .NET 8 SDK instalat.
2. Din folderul `Habits.Api`:

   ```bash
   dotnet build
   dotnet run
