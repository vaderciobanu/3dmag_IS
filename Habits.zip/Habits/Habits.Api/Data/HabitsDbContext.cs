using Habits.Api.Entities;
using Microsoft.EntityFrameworkCore;

namespace Habits.Api.Data;

public class HabitsDbContext : DbContext
{
    public HabitsDbContext(DbContextOptions<HabitsDbContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users => Set<User>();
    public DbSet<UserStats> UserStats => Set<UserStats>();
    public DbSet<TaskType> TaskTypes => Set<TaskType>();
    public DbSet<HabitTask> Tasks => Set<HabitTask>();
    public DbSet<TaskCompletionHistory> TaskCompletionHistories => Set<TaskCompletionHistory>();
    public DbSet<Reward> Rewards => Set<Reward>();
    public DbSet<UserRewardPurchase> UserRewardPurchases => Set<UserRewardPurchase>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // User - UserStats (1:1)
        modelBuilder.Entity<User>()
            .HasOne(u => u.Stats)
            .WithOne(s => s.User)
            .HasForeignKey<UserStats>(s => s.UserId);

        // User - HabitTask (1:M)
        modelBuilder.Entity<User>()
            .HasMany(u => u.Tasks)
            .WithOne(t => t.User)
            .HasForeignKey(t => t.UserId);

        // TaskType - HabitTask (1:M)
        modelBuilder.Entity<TaskType>()
            .HasMany(tt => tt.Tasks)
            .WithOne(t => t.TaskType)
            .HasForeignKey(t => t.TaskTypeId);

        // User - TaskCompletionHistory (1:M)
        modelBuilder.Entity<User>()
            .HasMany(u => u.TaskCompletions)
            .WithOne(c => c.User)
            .HasForeignKey(c => c.UserId);

        // HabitTask - TaskCompletionHistory (1:M)
        modelBuilder.Entity<HabitTask>()
            .HasMany(t => t.Completions)
            .WithOne(c => c.Task)
            .HasForeignKey(c => c.TaskId);

        // User - UserRewardPurchases (1:M)
        modelBuilder.Entity<User>()
            .HasMany(u => u.RewardPurchases)
            .WithOne(p => p.User)
            .HasForeignKey(p => p.UserId);

        // Reward - UserRewardPurchases (1:M)
        modelBuilder.Entity<Reward>()
            .HasMany(r => r.Purchases)
            .WithOne(p => p.Reward)
            .HasForeignKey(p => p.RewardId);
    }
}
