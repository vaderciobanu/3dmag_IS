using Habits.Api.Data;
using Habits.Api.Dtos;
using Habits.Api.Entities;
using Microsoft.EntityFrameworkCore;

namespace Habits.Api.Services;

public class TaskService : ITaskService
{
    private readonly HabitsDbContext _db;

    public TaskService(HabitsDbContext db)
    {
        _db = db;
    }

    public async Task<IEnumerable<TaskDto>> GetAllAsync(int? userId = null)
    {
        var query = _db.Tasks
            .Include(t => t.TaskType)
            .AsQueryable();

        if (userId.HasValue)
        {
            query = query.Where(t => t.UserId == userId.Value);
        }

        var tasks = await query.ToListAsync();
        return tasks.Select(MapToDto);
    }

    public async Task<TaskDto?> GetByIdAsync(int id)
    {
        var task = await _db.Tasks
            .Include(t => t.TaskType)
            .FirstOrDefaultAsync(t => t.Id == id);

        if (task == null)
            return null;

        return MapToDto(task);
    }

    public async Task<TaskDto> CreateAsync(CreateTaskDto dto)
    {
        // gasim TaskType dupa cod (HABIT / DAILY / TODO)
        var type = await _db.TaskTypes
            .FirstOrDefaultAsync(tt => tt.Code == dto.TaskTypeCode);

        if (type == null)
        {
            type = new TaskType
            {
                Name = dto.TaskTypeCode,
                Code = dto.TaskTypeCode
            };
            _db.TaskTypes.Add(type);
            await _db.SaveChangesAsync();
        }

        var task = new HabitTask
        {
            UserId = dto.UserId,
            TaskTypeId = type.Id,
            Title = dto.Title,
            Description = dto.Description,
            Difficulty = dto.Difficulty,
            IsActive = true,
            IsCompleted = false,
            DueDate = dto.DueDate,
            CreatedAt = DateTime.UtcNow
        };

        _db.Tasks.Add(task);
        await _db.SaveChangesAsync();

        // recitim cu TaskType pentru DTO complet
        await _db.Entry(task).Reference(t => t.TaskType).LoadAsync();

        return MapToDto(task);
    }

    public async Task<TaskDto?> UpdateAsync(int id, UpdateTaskDto dto)
    {
        var task = await _db.Tasks
            .Include(t => t.TaskType)
            .FirstOrDefaultAsync(t => t.Id == id);

        if (task == null)
            return null;

        task.Title = dto.Title;
        task.Description = dto.Description;
        task.Difficulty = dto.Difficulty;
        task.IsActive = dto.IsActive;
        task.DueDate = dto.DueDate;

        await _db.SaveChangesAsync();

        return MapToDto(task);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var task = await _db.Tasks.FindAsync(id);
        if (task == null)
            return false;

        _db.Tasks.Remove(task);
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<CompleteTaskResultDto?> CompleteAsync(int id)
    {
        var task = await _db.Tasks
            .Include(t => t.TaskType)
            .Include(t => t.User)
                .ThenInclude(u => u.Stats)
            .FirstOrDefaultAsync(t => t.Id == id);

        if (task == null)
            return null;

        var userStats = task.User.Stats;
        if (userStats == null)
            return null;

        // calcul XP / gold in functie de dificultate
        var (xp, gold) = GetRewardsForTask(task);

        userStats.Experience += xp;
        userStats.Gold += gold;

        int lostHp = 0; // la completare nu pierdem HP

        // daca e TODO, il marcam completat
        if (task.TaskType.Code == "TODO")
        {
            task.IsCompleted = true;
            task.IsActive = false;
        }

        // istoric
        var history = new TaskCompletionHistory
        {
            TaskId = task.Id,
            UserId = task.UserId,
            CompletedAt = DateTime.UtcNow,
            GainedXp = xp,
            GainedGold = gold,
            LostHp = lostHp
        };

        _db.TaskCompletionHistories.Add(history);

        await _db.SaveChangesAsync();

        return new CompleteTaskResultDto
        {
            Task = MapToDto(task),
            Stats = new UserStatsDto
            {
                Level = userStats.Level,
                Experience = userStats.Experience,
                HealthPoints = userStats.HealthPoints,
                Gold = userStats.Gold
            }
        };
    }

    private static (int xp, int gold) GetRewardsForTask(HabitTask task)
    {
        int xpBase = task.Difficulty.ToUpper() switch
        {
            "EASY" => 5,
            "HARD" => 20,
            _ => 10 // MEDIUM / default
        };

        int goldBase = task.Difficulty.ToUpper() switch
        {
            "EASY" => 1,
            "HARD" => 4,
            _ => 2
        };

        return (xpBase, goldBase);
    }

    private static TaskDto MapToDto(HabitTask task)
    {
        return new TaskDto
        {
            Id = task.Id,
            UserId = task.UserId,
            TaskTypeId = task.TaskTypeId,
            TaskTypeCode = task.TaskType?.Code ?? string.Empty,
            Title = task.Title,
            Description = task.Description,
            Difficulty = task.Difficulty,
            IsActive = task.IsActive,
            IsCompleted = task.IsCompleted,
            DueDate = task.DueDate,
            CreatedAt = task.CreatedAt
        };
    }
}
