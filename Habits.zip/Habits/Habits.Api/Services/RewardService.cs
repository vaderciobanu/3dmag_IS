using Habits.Api.Data;
using Habits.Api.Dtos;
using Habits.Api.Entities;
using Microsoft.EntityFrameworkCore;

namespace Habits.Api.Services;

public class RewardService : IRewardService
{
    private readonly HabitsDbContext _db;

    public RewardService(HabitsDbContext db)
    {
        _db = db;
    }

    public async Task<IEnumerable<RewardDto>> GetAllAsync()
    {
        var rewards = await _db.Rewards.ToListAsync();
        return rewards.Select(MapToDto);
    }

    public async Task<RewardDto?> GetByIdAsync(int id)
    {
        var reward = await _db.Rewards.FindAsync(id);
        if (reward == null)
            return null;

        return MapToDto(reward);
    }

    public async Task<RewardDto> CreateAsync(CreateRewardDto dto)
    {
        var reward = new Reward
        {
            Name = dto.Name,
            Description = dto.Description,
            CostGold = dto.CostGold,
            IsActive = true
        };

        _db.Rewards.Add(reward);
        await _db.SaveChangesAsync();

        return MapToDto(reward);
    }

    public async Task<RewardDto?> UpdateAsync(int id, UpdateRewardDto dto)
    {
        var reward = await _db.Rewards.FindAsync(id);
        if (reward == null)
            return null;

        reward.Name = dto.Name;
        reward.Description = dto.Description;
        reward.CostGold = dto.CostGold;
        reward.IsActive = dto.IsActive;

        await _db.SaveChangesAsync();

        return MapToDto(reward);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var reward = await _db.Rewards.FindAsync(id);
        if (reward == null)
            return false;

        _db.Rewards.Remove(reward);
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<RewardPurchaseResultDto?> PurchaseAsync(int rewardId, int userId)
    {
        var reward = await _db.Rewards.FirstOrDefaultAsync(r => r.Id == rewardId && r.IsActive);
        if (reward == null)
            return null;

        var user = await _db.Users
            .Include(u => u.Stats)
            .FirstOrDefaultAsync(u => u.Id == userId);

        if (user == null || user.Stats == null)
            return null;

        if (user.Stats.Gold < reward.CostGold)
        {
            // nu are destul gold => nu cumpara
            return null;
        }

        user.Stats.Gold -= reward.CostGold;

        var purchase = new UserRewardPurchase
        {
            UserId = user.Id,
            RewardId = reward.Id,
            PurchasedAt = DateTime.UtcNow
        };

        _db.UserRewardPurchases.Add(purchase);

        await _db.SaveChangesAsync();

        return new RewardPurchaseResultDto
        {
            Reward = MapToDto(reward),
            Stats = new UserStatsDto
            {
                Level = user.Stats.Level,
                Experience = user.Stats.Experience,
                HealthPoints = user.Stats.HealthPoints,
                Gold = user.Stats.Gold
            }
        };
    }

    private static RewardDto MapToDto(Reward reward)
    {
        return new RewardDto
        {
            Id = reward.Id,
            Name = reward.Name,
            Description = reward.Description,
            CostGold = reward.CostGold,
            IsActive = reward.IsActive
        };
    }
}
