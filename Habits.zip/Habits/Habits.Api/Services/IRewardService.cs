using Habits.Api.Dtos;

namespace Habits.Api.Services;

public interface IRewardService
{
    Task<IEnumerable<RewardDto>> GetAllAsync();
    Task<RewardDto?> GetByIdAsync(int id);
    Task<RewardDto> CreateAsync(CreateRewardDto dto);
    Task<RewardDto?> UpdateAsync(int id, UpdateRewardDto dto);
    Task<bool> DeleteAsync(int id);
    Task<RewardPurchaseResultDto?> PurchaseAsync(int rewardId, int userId);
}
