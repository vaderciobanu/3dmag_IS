using Habits.Api.Dtos;

namespace Habits.Api.Services;

public interface ITaskService
{
    Task<IEnumerable<TaskDto>> GetAllAsync(int? userId = null);
    Task<TaskDto?> GetByIdAsync(int id);
    Task<TaskDto> CreateAsync(CreateTaskDto dto);
    Task<TaskDto?> UpdateAsync(int id, UpdateTaskDto dto);
    Task<bool> DeleteAsync(int id);
    Task<CompleteTaskResultDto?> CompleteAsync(int id);
}
