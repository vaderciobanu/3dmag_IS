using Habits.Api.Data;
using Habits.Api.Dtos;
using Habits.Api.Entities;
using Microsoft.EntityFrameworkCore;

namespace Habits.Api.Services;

public class UserService : IUserService
{
    private readonly HabitsDbContext _db;

    public UserService(HabitsDbContext db)
    {
        _db = db;
    }

    public async Task<IEnumerable<UserDto>> GetAllAsync()
    {
        var users = await _db.Users
            .Include(u => u.Stats)
            .ToListAsync();

        return users.Select(MapToDto);
    }

    public async Task<UserDto?> GetByIdAsync(int id)
    {
        var user = await _db.Users
            .Include(u => u.Stats)
            .FirstOrDefaultAsync(u => u.Id == id);

        if (user == null)
            return null;

        return MapToDto(user);
    }

    public async Task<UserDto> CreateAsync(CreateUserDto dto)
    {
        var user = new User
        {
            Username = dto.Username,
            Email = dto.Email,
            PasswordHash = dto.Password, // in real life: hash, aici simplu
            CreatedAt = DateTime.UtcNow
        };

        // Cream direct stats default pentru user
        var stats = new UserStats
        {
            User = user,
            Level = 1,
            Experience = 0,
            HealthPoints = 100,
            Gold = 0
        };

        user.Stats = stats;

        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        return MapToDto(user);
    }

    public async Task<UserDto?> UpdateAsync(int id, UpdateUserDto dto)
    {
        var user = await _db.Users
            .Include(u => u.Stats)
            .FirstOrDefaultAsync(u => u.Id == id);

        if (user == null)
            return null;

        user.Username = dto.Username;
        user.Email = dto.Email;

        if (!string.IsNullOrWhiteSpace(dto.Password))
        {
            user.PasswordHash = dto.Password;
        }

        await _db.SaveChangesAsync();

        return MapToDto(user);
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var user = await _db.Users.FindAsync(id);
        if (user == null)
            return false;

        _db.Users.Remove(user);
        await _db.SaveChangesAsync();
        return true;
    }

    private static UserDto MapToDto(User user)
    {
        return new UserDto
        {
            Id = user.Id,
            Username = user.Username,
            Email = user.Email,
            CreatedAt = user.CreatedAt,
            Stats = user.Stats == null
                ? null
                : new UserStatsDto
                {
                    Level = user.Stats.Level,
                    Experience = user.Stats.Experience,
                    HealthPoints = user.Stats.HealthPoints,
                    Gold = user.Stats.Gold
                }
        };
    }
}
