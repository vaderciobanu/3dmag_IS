using Habits.Api.Dtos;
using Habits.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace Habits.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RewardsController : ControllerBase
{
    private readonly IRewardService _rewardService;

    public RewardsController(IRewardService rewardService)
    {
        _rewardService = rewardService;
    }

    // GET: api/Rewards
    [HttpGet]
    public async Task<ActionResult<IEnumerable<RewardDto>>> GetAll()
    {
        var rewards = await _rewardService.GetAllAsync();
        return Ok(rewards);
    }

    // GET: api/Rewards/5
    [HttpGet("{id:int}")]
    public async Task<ActionResult<RewardDto>> GetById(int id)
    {
        var reward = await _rewardService.GetByIdAsync(id);
        if (reward == null)
            return NotFound();

        return Ok(reward);
    }

    // POST: api/Rewards
    [HttpPost]
    public async Task<ActionResult<RewardDto>> Create([FromBody] CreateRewardDto dto)
    {
        var created = await _rewardService.CreateAsync(dto);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    // PUT: api/Rewards/5
    [HttpPut("{id:int}")]
    public async Task<ActionResult<RewardDto>> Update(int id, [FromBody] UpdateRewardDto dto)
    {
        var updated = await _rewardService.UpdateAsync(id, dto);
        if (updated == null)
            return NotFound();

        return Ok(updated);
    }

    // DELETE: api/Rewards/5
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var deleted = await _rewardService.DeleteAsync(id);
        if (!deleted)
            return NotFound();

        return NoContent();
    }

    // POST: api/Rewards/5/purchase
    [HttpPost("{id:int}/purchase")]
    public async Task<ActionResult<RewardPurchaseResultDto>> Purchase(int id, [FromBody] PurchaseRewardDto dto)
    {
        var result = await _rewardService.PurchaseAsync(id, dto.UserId);
        if (result == null)
            return BadRequest("Cannot purchase reward (not found, inactive or insufficient gold).");

        return Ok(result);
    }
}
