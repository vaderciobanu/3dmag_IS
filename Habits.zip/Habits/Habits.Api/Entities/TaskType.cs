namespace Habits.Api.Entities;

public class TaskType
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;  // Habit, Daily, Todo
    public string Code { get; set; } = null!;  // HABIT, DAILY, TODO

    public ICollection<HabitTask> Tasks { get; set; } = new List<HabitTask>();
}
