namespace Habits.Api.Entities;

public class HabitTask
{
    public int Id { get; set; }

    public int UserId { get; set; }
    public int TaskTypeId { get; set; }

    public string Title { get; set; } = null!;
    public string? Description { get; set; }

    public string Difficulty { get; set; } = "MEDIUM"; // EASY / MEDIUM / HARD
    public bool IsActive { get; set; } = true;
    public bool IsCompleted { get; set; } = false;

    public DateTime? DueDate { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public User User { get; set; } = null!;
    public TaskType TaskType { get; set; } = null!;
    public ICollection<TaskCompletionHistory> Completions { get; set; } = new List<TaskCompletionHistory>();
}
