namespace Habits.Api.Entities;

public class UserStats
{
    public int Id { get; set; }
    public int UserId { get; set; }

    public int Level { get; set; } = 1;
    public int Experience { get; set; } = 0;
    public int HealthPoints { get; set; } = 100;
    public int Gold { get; set; } = 0;

    public User User { get; set; } = null!;
}
