namespace Habits.Api.Entities;

public class UserRewardPurchase
{
    public int Id { get; set; }

    public int UserId { get; set; }
    public int RewardId { get; set; }

    public DateTime PurchasedAt { get; set; } = DateTime.UtcNow;

    public User User { get; set; } = null!;
    public Reward Reward { get; set; } = null!;
}
