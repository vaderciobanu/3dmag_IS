namespace Habits.Api.Entities;

public class Reward
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;
    public string? Description { get; set; }

    public int CostGold { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<UserRewardPurchase> Purchases { get; set; } = new List<UserRewardPurchase>();
}
