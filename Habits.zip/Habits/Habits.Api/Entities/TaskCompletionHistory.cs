namespace Habits.Api.Entities;

public class TaskCompletionHistory
{
    public int Id { get; set; }

    public int TaskId { get; set; }
    public int UserId { get; set; }

    public DateTime CompletedAt { get; set; } = DateTime.UtcNow;

    public int GainedXp { get; set; }
    public int GainedGold { get; set; }
    public int LostHp { get; set; }

    public HabitTask Task { get; set; } = null!;
    public User User { get; set; } = null!;
}
