namespace Habits.Api.Entities;

public class User
{
    public int Id { get; set; }

    public string Username { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string PasswordHash { get; set; } = null!;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Relatii
    public UserStats Stats { get; set; } = null!;
    public ICollection<HabitTask> Tasks { get; set; } = new List<HabitTask>();
    public ICollection<TaskCompletionHistory> TaskCompletions { get; set; } = new List<TaskCompletionHistory>();
    public ICollection<UserRewardPurchase> RewardPurchases { get; set; } = new List<UserRewardPurchase>();
}
