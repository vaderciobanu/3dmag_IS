using Habits.Api.Data;
using Habits.Api.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Connection string din appsettings.json
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

// DbContext + SQLite
builder.Services.AddDbContext<HabitsDbContext>(options =>
{
    options.UseSqlite(connectionString);
});

// Services pentru API cu controllere
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<ITaskService, TaskService>();
builder.Services.AddScoped<IRewardService, RewardService>();

builder.Services.AddControllers();

// Swagger / OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Pipeline HTTP
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.MapControllers();

app.Run();
