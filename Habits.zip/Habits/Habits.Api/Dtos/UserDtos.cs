namespace Habits.Api.Dtos;

public class UserDto
{
    public int Id { get; set; }

    public string Username { get; set; } = null!;
    public string Email { get; set; } = null!;
    public DateTime CreatedAt { get; set; }

    public UserStatsDto? Stats { get; set; }
}

public class UserStatsDto
{
    public int Level { get; set; }
    public int Experience { get; set; }
    public int HealthPoints { get; set; }
    public int Gold { get; set; }
}

public class CreateUserDto
{
    public string Username { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string Password { get; set; } = null!;
}

public class UpdateUserDto
{
    public string Username { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string? Password { get; set; }
}
