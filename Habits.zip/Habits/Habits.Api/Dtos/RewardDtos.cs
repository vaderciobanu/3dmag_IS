namespace Habits.Api.Dtos;

public class RewardDto
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;
    public string? Description { get; set; }

    public int CostGold { get; set; }
    public bool IsActive { get; set; }
}

public class CreateRewardDto
{
    public string Name { get; set; } = null!;
    public string? Description { get; set; }

    public int CostGold { get; set; }
}

public class UpdateRewardDto
{
    public string Name { get; set; } = null!;
    public string? Description { get; set; }

    public int CostGold { get; set; }
    public bool IsActive { get; set; } = true;
}

// pentru request la cumparare
public class PurchaseRewardDto
{
    public int UserId { get; set; }
}

// ce intoarcem la cumparare
public class RewardPurchaseResultDto
{
    public RewardDto Reward { get; set; } = null!;
    public UserStatsDto Stats { get; set; } = null!;
}
