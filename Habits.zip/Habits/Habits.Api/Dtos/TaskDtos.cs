using Habits.Api.Entities;

namespace Habits.Api.Dtos;

public class TaskDto
{
    public int Id { get; set; }

    public int UserId { get; set; }
    public int TaskTypeId { get; set; }
    public string TaskTypeCode { get; set; } = null!;  // HABIT / DAILY / TODO

    public string Title { get; set; } = null!;
    public string? Description { get; set; }

    public string Difficulty { get; set; } = null!; // EASY / MEDIUM / HARD
    public bool IsActive { get; set; }
    public bool IsCompleted { get; set; }

    public DateTime? DueDate { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class CreateTaskDto
{
    public int UserId { get; set; }

    // HABIT / DAILY / TODO
    public string TaskTypeCode { get; set; } = null!;

    public string Title { get; set; } = null!;
    public string? Description { get; set; }

    // EASY / MEDIUM / HARD
    public string Difficulty { get; set; } = "MEDIUM";

    public DateTime? DueDate { get; set; }
}

public class UpdateTaskDto
{
    public string Title { get; set; } = null!;
    public string? Description { get; set; }
    public string Difficulty { get; set; } = "MEDIUM";
    public bool IsActive { get; set; } = true;
    public DateTime? DueDate { get; set; }
}

// ce intoarcem la completare task
public class CompleteTaskResultDto
{
    public TaskDto Task { get; set; } = null!;
    public UserStatsDto Stats { get; set; } = null!;
}
